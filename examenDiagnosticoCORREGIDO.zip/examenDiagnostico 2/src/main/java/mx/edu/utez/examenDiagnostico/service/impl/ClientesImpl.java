package mx.edu.utez.examenDiagnostico.service.impl;

import lombok.AllArgsConstructor;
import mx.edu.utez.examenDiagnostico.model.dao.ClientesDao;
import mx.edu.utez.examenDiagnostico.model.dto.ClientesDto;
import mx.edu.utez.examenDiagnostico.model.entity.ClientesBean;
import mx.edu.utez.examenDiagnostico.service.IClientes;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@AllArgsConstructor
public class ClientesImpl implements IClientes {
    private ClientesDao clientesDao;

    @Override
    @Transactional
    public ClientesBean save(ClientesDto clientesDto) {
        ClientesBean clientesBean = ClientesBean.builder()
                .idclientes(clientesDto.getIdclientes())
                .Nombre(clientesDto.getNombre())
                .Apellidos(clientesDto.getApellidos())
                .Curp(clientesDto.getCurp())
                .FechaNacimiento(clientesDto.getFechaNacimiento())
                .build();
        return clientesDao.save(clientesBean);
    }

    @Override
    @Transactional(readOnly = true)
    public ClientesBean findById(Integer id) {
        return clientesDao.findById(id).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ClientesBean> findAll() {
        return (List<ClientesBean>) clientesDao.findAll();
    }

    @Override
    public void delete(ClientesBean branch) {
        clientesDao.delete(branch);
    }
}
