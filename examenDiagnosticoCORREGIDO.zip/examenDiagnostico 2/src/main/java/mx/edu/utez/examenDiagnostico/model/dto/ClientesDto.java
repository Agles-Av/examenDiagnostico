package mx.edu.utez.examenDiagnostico.model.dto;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ClientesDto {
    private Integer idclientes;
    private String Nombre;
    private String Apellidos;
    private String Curp;
    private String FechaNacimiento;
}
