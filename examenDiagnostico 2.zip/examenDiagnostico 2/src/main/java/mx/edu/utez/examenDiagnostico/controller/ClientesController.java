package mx.edu.utez.examenDiagnostico.controller;

import lombok.AllArgsConstructor;
import mx.edu.utez.examenDiagnostico.model.dto.ClientesDto;
import mx.edu.utez.examenDiagnostico.model.entity.ClientesBean;
import mx.edu.utez.examenDiagnostico.service.IClientes;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/clientes")
@AllArgsConstructor
public class ClientesController {
    private IClientes clientesService;

    @GetMapping("/")
    @CrossOrigin(origins = "*",allowedHeaders = "*")
    public List<ClientesBean> getBranch() {
        return clientesService.findAll();
    }

    @GetMapping("/{id}")
    @CrossOrigin(origins = "*",allowedHeaders = "*")
    public ClientesBean showById(@PathVariable Integer id) {
        return clientesService.findById(id);
    }

    @PostMapping("/")
    @CrossOrigin(origins = "*",allowedHeaders = "*")
    public ClientesDto create(@RequestBody ClientesDto clientesDto) {
        ClientesBean branchSave = clientesService.save(clientesDto);
        return ClientesDto.builder()
                .idclientes(branchSave.getIdclientes())
                .Nombre(branchSave.getNombre())
                .Apellidos(branchSave.getApellidos())
                .Curp(branchSave.getCurp())
                .FechaNacimiento(branchSave.getFechaNacimiento())
                .build();
    }

    @PutMapping("/")
    @CrossOrigin(origins = "*",allowedHeaders = "*",methods = {RequestMethod.PUT})
    public ClientesDto update(@RequestBody ClientesDto branchDto) {
        ClientesBean branchUpdate = clientesService.save(branchDto);
        return ClientesDto.builder()
                .idclientes(branchUpdate.getIdclientes())
                .Nombre(branchUpdate.getNombre())
                .Apellidos(branchUpdate.getApellidos())
                .Curp(branchUpdate.getCurp())
                .FechaNacimiento(branchUpdate.getFechaNacimiento())
                .build();
    }

    @DeleteMapping("/{id}")
    @CrossOrigin(origins = "*",allowedHeaders = "*")
    public ResponseEntity<?> delete(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        try {
            ClientesBean clientesBean = clientesService.findById(id);
            clientesService.delete(clientesBean);
            response.put("mensaje", "Cliente eliminado correctamente");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (DataAccessException e) {
            response.put("mensaje", "Error al eliminar el cliente");
            response.put("Empleado", null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
