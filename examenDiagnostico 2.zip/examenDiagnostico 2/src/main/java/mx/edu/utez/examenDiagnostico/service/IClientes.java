package mx.edu.utez.examenDiagnostico.service;

import mx.edu.utez.examenDiagnostico.model.dto.ClientesDto;
import mx.edu.utez.examenDiagnostico.model.entity.ClientesBean;

import java.util.List;

public interface IClientes {
    ClientesBean save(ClientesDto branch);

    ClientesBean findById(Integer id);

    List<ClientesBean> findAll();

    void delete(ClientesBean branch);
}
