package mx.edu.utez.examenDiagnostico.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "clientes")
public class ClientesBean {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_clientes")
    private Integer idclientes;
    @Column(name = "nombre", nullable = false)
    private String Nombre;
    @Column(name = "apellidos", nullable = false)
    private String Apellidos;
    @Column(name = "curp", nullable = false)
    private String Curp;
    @Column(name = "fechanac", nullable = false)
    private String FechaNacimiento;

}
